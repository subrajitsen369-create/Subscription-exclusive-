# Channel Subscription Bot — Vercel version

## What changed
- Converted the Telegram bot from long-running polling to a Vercel Flask webhook.
- Removed the Render keep-alive server.
- Added `api/index.py` as the Vercel entrypoint.
- Added `/api/webhook` for Telegram updates.
- Added `/api/expire` for subscription-expiry processing.
- Preserved the original polling bot as `bot_polling_original.py`.

## Vercel Environment Variables
Keep your existing variables:
- `BOT_TOKEN`
- `MONGO_URI`
- `ADMIN_ID`
- `UPI_ID`
- `CONTACT_USERNAME`

Optional:
- `CRON_SECRET` — recommended if you use an external cron service to call `/api/expire`.

## IMPORTANT: set the Telegram webhook
After deployment, set Telegram's webhook to:

`https://YOUR-VERCEL-DOMAIN.vercel.app/api/webhook`

You can do this once using Telegram's Bot API `setWebhook` method with your existing BOT_TOKEN. This does NOT require a new API key.

## Important limitation
Vercel serverless functions are not a permanent background process. The original one-minute APScheduler loop cannot run continuously on Vercel.

The `/api/expire` endpoint contains the expiry logic, so use an external cron service to call it periodically if you need automatic expiry/kicking. The bot's normal Telegram webhook functionality does not require a separate API key.

## Existing interactive flow
The project uses `pyTelegramBotAPI`'s in-memory next-step handlers for `/add`. Serverless instances can be restarted, so multi-step admin conversations may need persistent MongoDB state for maximum reliability.
